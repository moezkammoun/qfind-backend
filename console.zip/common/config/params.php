<?php
return [
    'adminEmail' => 'aathira@intersmart.in',
    'supportEmail' => 'aathira@intersmart.in',
    'noReplyEmail' => 'aathira@intersmart.in',
    'user.passwordResetTokenExpire' => 3600,
];
