<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "brand".
 *
 * @property integer $id
 * @property string $name
 * @property string $image
 * @property string $canonical_name
 * @property integer $sort_order
 * @property integer $status
 */
class Brand extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'brand';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'canonical_name', 'status'], 'required'],
            [['sort_order', 'status'], 'integer'],
            [['name', 'image', 'canonical_name'], 'string', 'max' => 250],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'image' => 'Image',
            'canonical_name' => 'Canonical Name',
            'sort_order' => 'Sort Order',
            'status' => 'Status',
        ];
    }
    public function upload($file, $id, $name) {

        $targetFolder = \yii::$app->basePath . '/../uploads/brand/' . $id . '/';
        if (!file_exists($targetFolder)) {
            mkdir($targetFolder, 0777, true);
        }
        if ($file->saveAs($targetFolder . $name)) {
            return true;
        } else {
            return false;
        }
    }
}
