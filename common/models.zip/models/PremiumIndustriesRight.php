<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "premium_industries_right".
 *
 * @property integer $id
 * @property integer $main_industry
 * @property integer $sub_industry
 * @property integer $sort_order
 * @property integer $status
 */
class PremiumIndustriesRight extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'premium_industries_right';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['main_industry', 'sub_industry'], 'required'],
                    ['sub_industry', 'unique'],
                    [['main_industry', 'sub_industry', 'sort_order', 'status'], 'integer'],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'main_industry' => 'Main Industry',
                    'sub_industry' => 'Premium Industry Right',
                    'sort_order' => 'Sort Order',
                    'status' => 'Status',
                ];
        }

        public function getMainind() {
                return $this->hasOne(\backend\models\IndustriesMaster::className(), ['id' => 'main_industry']);
        }

        public function getSubind() {
                return $this->hasOne(\backend\models\IndustriesMaster::className(), ['id' => 'sub_industry']);
        }

}
