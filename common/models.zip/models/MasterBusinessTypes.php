<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "master_business_types".
 *
 * @property integer $id
 * @property string $name
 * @property string $canonical_name
 * @property integer $parent_id
 * @property string $image
 * @property integer $status
 */
class MasterBusinessTypes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'master_business_types';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'canonical_name', 'parent_id', 'status'], 'required'],
            [['parent_id', 'status','sort_order'], 'integer'],
            [['name', 'canonical_name', 'image'], 'string', 'max' => 250],
            ['canonical_name', 'unique', 'targetAttribute' => ['canonical_name'], 'message' => 'Canonical Name must be unique.'],
            ['canonical_name', 'match', 'pattern' => '/^[A-Za-z0-9-]+$/'], 
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'canonical_name' => 'Canonical Name',
            'parent_id' => ' Select Master Business Type',
            'image' => 'Image',
            'status' => 'Status',
            'sort_order'=>'Sort Order',
        ];
    }
   
    public function upload($file, $id, $name) {

        $targetFolder = \yii::$app->basePath . '/../uploads/master-business-types/' . $id . '/';
        if (!file_exists($targetFolder)) {
            mkdir($targetFolder, 0777, true);
        }
        if ($file->saveAs($targetFolder . $name)) {
            return true;
        } else {
            return false;
        }
    }
}
