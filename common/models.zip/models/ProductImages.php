<?php

namespace common\models;

use Yii;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "product_images".
 *
 * @property integer $id
 * @property string $image
 * @property integer $status
 * @property string $created_on
 * @property integer $sort_order
 * @property integer $created_by
 * @property integer $product_id
 * @property string $main_image
 */
class ProductImages extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'product_images';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['image', 'product_id'], 'required'],
                    ['image', 'unique', 'targetAttribute' => 'product_id'],
                    [['status', 'sort_order', 'created_by', 'product_id'], 'integer'],
                    [['created_on'], 'safe'],
                        //[['image', 'main_image'], 'string', 'max' => 200],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'image' => 'Image',
                    'status' => 'Status',
                    'created_on' => 'Created On',
                    'sort_order' => 'Sort Order',
                    'created_by' => 'Created By',
                    'product_id' => 'Product ID',
                    'main_image' => 'Main Image',
                ];
        }

        public function loadImages($id) {
                $query = ProductImages::find();
                $dataProvider = new ActiveDataProvider([
                    'query' => $query,
                ]);
                $query->andFilterWhere([
                    'id' => $this->id,
                    'status' => $this->status,
                    'created_on' => $this->created_on,
                    'sort_order' => $this->sort_order,
                    'created_by' => $this->created_by,
                    'product_id' => $id,
                ]);
                return $dataProvider;
        }

        public function upload($file, $id) {
                $targetFolder = \yii::$app->basePath . '/../uploads/products/' . $id . '/';
                if (!file_exists($targetFolder)) {
                        mkdir($targetFolder, 0777, true);
                }
                if ($file->saveAs($targetFolder . $file->name)) {
                        return true;
                } else {
                        return false;
                }
        }

}
