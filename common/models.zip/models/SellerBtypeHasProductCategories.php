<?php

namespace common\models;

use Yii;
use common\models\SellerBusinessTypes;
use backend\models\CategoriesMaster;

/**
 * This is the model class for table "seller_btype_has_product_categories".
 *
 * @property integer $id
 * @property integer $seller_btype_id
 * @property integer $product_category_id
 *
 * @property SellerBusinessTypes $sellerBtype
 * @property CategoriesMaster $productCategory
 */
class SellerBtypeHasProductCategories extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'seller_btype_has_product_categories';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['seller_btype_id', 'product_category_id', 'seller_id'], 'required'],
                [['seller_btype_id', 'product_category_id'], 'integer'],
            [['product_category_id'], 'unique'],
            [['seller_btype_id'], 'exist', 'skipOnError' => true, 'targetClass' => SellerBusinessTypes::className(), 'targetAttribute' => ['seller_btype_id' => 'id']],
            [['product_category_id'], 'exist', 'skipOnError' => true, 'targetClass' => CategoriesMaster::className(), 'targetAttribute' => ['product_category_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'seller_btype_id' => 'Seller Btype ID',
            'product_category_id' => 'Product Category ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSellerBtype()
    {
        return $this->hasOne(SellerBusinessTypes::className(), ['id' => 'seller_btype_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProductCategory()
    {
        return $this->hasOne(CategoriesMaster::className(), ['id' => 'product_category_id']);
    }
}
