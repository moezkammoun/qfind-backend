<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "company_profile".
 *
 * @property integer $id
 * @property integer $seller_id
 * @property string $address_line1
 * @property string $address_line2
 * @property integer $country
 * @property integer $state
 * @property integer $city
 * @property string $landmark
 * @property string $logo
 * @property string $digital_certificate
 * @property string $registration_certificate
 */
class CompanyProfile extends \yii\db\ActiveRecord {

        public $is_company;

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'company_profile';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['seller_id', 'company_name', 'company_canonical_name'], 'required', 'when' => function ($model) {
                        return $model->is_company == 1;
                }, 'whenClient' => "function (attribute, value) { return $('#companyprofile-is_company').val() == 1; }"],
                    [['address_line1', 'country', 'state', 'city', 'pincode', 'about_us'], 'required', 'on' => 'secondLevel'],
                    [['address_line1', 'country', 'city', 'pincode', 'about_us', 'establishment_year', 'registration_certificate',
                    'firm_legal_status', 'no_of_employees', 'annual_turnover', 'cst_number', 'vat_number', 'tan_number', 'service_tax_number', 'company_ceo', 'gst_no'], 'safe'],
                    [['pincode'], 'number', 'min' => 0],
//                [['establishment_year'], 'date', 'format' => 'yyyy'],
                    [['establishment_year'], 'number', 'integerOnly' => true, 'min' => 1000,
                        'tooSmall' => 'Invalid Year!!!',
                        'max' => 2500,
                        'tooBig' => 'Invalid Year'],
                    [['seller_id', 'country', 'state'], 'integer'],
                    [['address_line1', 'address_line2'], 'string', 'max' => 254],
                    [['landmark', 'logo', 'digital_certificate', 'registration_certificate'], 'string', 'max' => 200],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'seller_id' => 'Seller ID',
                    'address_line1' => 'Address',
                    'address_line2' => 'Address Line2',
                    'country' => 'Country',
                    'state' => 'State',
                    'city' => 'City',
                    'landmark' => 'Landmark',
                    'logo' => 'Logo',
                    'digital_certificate' => 'Digital Certificate',
                    'registration_certificate' => 'Registration Certificate',
                ];
        }

}
