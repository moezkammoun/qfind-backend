<?php

namespace common\models;

use backend\models\CategoriesMaster;
use backend\models\IndustriesMaster;
use yii\data\ActiveDataProvider;
use Yii;

/**
 * This is the model class for table "products".
 *
 * @property integer $id
 * @property integer $seller_id
 * @property string $name
 * @property integer $business_nature
 * @property integer $status
 * @property string $created_on
 * @property integer $created_by
 * @property string $updated_on
 * @property integer $updated_by
 * @property integer $brand
 * @property string $short_description
 * @property string $canonical_name
 * @property integer $category_id
 * @property integer $industry_id
 * @property integer $mesured_in
 * @property double $price
 * @property string $product_code
 */
class Products extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'products';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['seller_id', 'name', 'business_nature', 'created_by', 'brand', 'short_description', 'canonical_name', 'category_id', 'industry_id', 'mesured_in'], 'required'],
                    [['seller_id', 'business_nature', 'status', 'created_by', 'updated_by', 'brand', 'category_id', 'industry_id', 'mesured_in'], 'integer'],
                    [['created_on', 'updated_on'], 'safe'],
                    [['short_description'], 'string'],
                    [['price'], 'number'],
                    [['name'], 'string', 'max' => 254],
                    [['canonical_name'], 'string', 'max' => 200],
                    [['product_code'], 'string', 'max' => 50],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'seller_id' => 'Seller ID',
                    'name' => 'Name',
                    'business_nature' => 'Business Nature',
                    'status' => 'Status',
                    'created_on' => 'Created On',
                    'created_by' => 'Created By',
                    'updated_on' => 'Updated On',
                    'updated_by' => 'Updated By',
                    'brand' => 'Brand',
                    'short_description' => 'Short Description',
                    'canonical_name' => 'Canonical Name',
                    'category_id' => 'Category ID',
                    'industry_id' => 'Industry ID',
                    'mesured_in' => 'Mesured In',
                    'price' => 'Price',
                    'product_code' => 'Product Code',
                ];
        }

        public function arrayCategory() {
                $categories = [];
                $results = \backend\models\CategoriesMaster::find()->where(['status' => 1])->all();
                foreach ($results as $mainCategory) {
                        $subCat = $this->arraySubCat($mainCategory->id, $mainCategory->name);
                        if (!empty($subCat)) {
                                $categories[$subCat['id']] = $subCat['name'];
                        }
                }
                return $categories;
        }

        public function arraySubCat($cat_id = 0, $name) {
                $results = \backend\models\CategoriesMaster::find()->where(['status' => 1, 'parent_id' => $cat_id])->all();
                if (count($results) > 0) {
                        return $subCat = [];
                } else {
                        $res = \backend\models\CategoriesMaster::findOne($cat_id);
                        $subCat['id'] = $name . '->' . $res->id;
                        $subCat['name'] = $res->name;
                        return $subCat;
                }
        }

        public function categorySubTree() {
                $cat = [];
                $categories = CategoriesMaster::find()->where(['status' => 1, 'parent_id' => 0])->all();
                foreach ($categories as $category) {
                        $Level1categories = CategoriesMaster::find()->where(['status' => 1, 'parent_id' => $category->id])->all();
                        if (count($Level1categories) > 0) {
                                foreach ($Level1categories as $Level1category) {
                                        $Level2categories = CategoriesMaster::find()->where(['status' => 1, 'parent_id' => $Level1category->id])->all();
                                        if (count($Level2categories) > 0) {
                                                foreach ($Level2categories as $Level2category) {
                                                        $Level3categories = CategoriesMaster::find()->where(['status' => 1, 'parent_id' => $Level2category->id])->all();
                                                        if (count($Level3categories) > 0) {
                                                                foreach ($Level3categories as $Level3category) {
                                                                        $Level4categories = CategoriesMaster::find()->where(['status' => 1, 'parent_id' => $Level3category->id])->all();
                                                                        if (count($Level4categories) > 0) {
                                                                                foreach ($Level4categories as $Level4category) {
                                                                                        $cat[$Level4category->id] = $category->name . ' / ' . $Level1category->name . ' / ' . $Level2category->name . ' / ' . $Level3category->name . ' / ' . $Level4category->name;
                                                                                }
                                                                        } else {
                                                                                $cat[$Level3category->id] = $category->name . ' / ' . $Level1category->name . ' / ' . $Level2category->name . ' / ' . $Level3category->name;
                                                                        }
                                                                }
                                                        } else {
                                                                $cat[$Level2category->id] = $category->name . ' / ' . $Level1category->name . ' / ' . $Level2category->name;
                                                        }
                                                }
                                        } else {
                                                $cat[$Level1category->id] = $category->name . ' / ' . $Level1category->name;
                                        }
                                }
                        } else {
                                $cat[$category->id] = $category->name;
                        }
                }


                return $cat;
        }

        public function industrySubTree() {
                $cat = [];
                $categories = IndustriesMaster::find()->where(['status' => 1, 'parent_id' => 0])->all();
                foreach ($categories as $category) {
                        $Level1categories = IndustriesMaster::find()->where(['status' => 1, 'parent_id' => $category->id])->all();
                        if (count($Level1categories) > 0) {
                                foreach ($Level1categories as $Level1category) {
                                        $Level2categories = IndustriesMaster::find()->where(['status' => 1, 'parent_id' => $Level1category->id])->all();
                                        if (count($Level2categories) > 0) {
                                                foreach ($Level2categories as $Level2category) {
                                                        $Level3categories = IndustriesMaster::find()->where(['status' => 1, 'parent_id' => $Level2category->id])->all();
                                                        if (count($Level3categories) > 0) {
                                                                foreach ($Level3categories as $Level3category) {
                                                                        $Level4categories = IndustriesMaster::find()->where(['status' => 1, 'parent_id' => $Level3category->id])->all();
                                                                        if (count($Level4categories) > 0) {
                                                                                foreach ($Level4categories as $Level4category) {
                                                                                        $cat[$Level4category->id] = $category->name . ' / ' . $Level1category->name . ' / ' . $Level2category->name . ' / ' . $Level3category->name . ' / ' . $Level4category->name;
                                                                                }
                                                                        } else {
                                                                                $cat[$Level3category->id] = $category->name . ' / ' . $Level1category->name . ' / ' . $Level2category->name . ' / ' . $Level3category->name;
                                                                        }
                                                                }
                                                        } else {
                                                                $cat[$Level2category->id] = $category->name . ' / ' . $Level1category->name . ' / ' . $Level2category->name;
                                                        }
                                                }
                                        } else {
                                                $cat[$Level1category->id] = $category->name . ' / ' . $Level1category->name;
                                        }
                                }
                        } else {
                                $cat[$category->id] = $category->name;
                        }
                }


                return $cat;
        }

        public function loadOtherProducts($id, $sellerId) {
                $query = Products::find();
                $dataProvider = new ActiveDataProvider([
                    'query' => $query,
                ]);

                $query->andFilterWhere([
                    'business_nature' => $this->business_nature,
                    'status' => $this->status,
                    'created_on' => $this->created_on,
                    'created_by' => $this->created_by,
                    'updated_on' => $this->updated_on,
                    'updated_by' => $this->updated_by,
                    'brand' => $this->brand,
                    'category_id' => $this->category_id,
                    'industry_id' => $this->industry_id,
                    'mesured_in' => $this->mesured_in,
                    'price' => $this->price,
                ]);
                $query->andFilterWhere(['=', 'id', $id])
                        ->andFilterWhere(['=', 'seller_id', $sellerId]);
                return $dataProvider;
        }

        public function getBusinessNature() {
                return $this->hasOne(BusinessNature::className(), ['id' => 'business_nature']);
        }

        public function getSeller() {
                return $this->hasOne(Sellers::className(), ['id' => 'seller_id']);
        }

        public function getBrand() {
                return $this->hasOne(Brand::className(), ['id' => 'brand']);
        }

        public function getCategory() {
                return $this->hasOne(\backend\models\CategoriesMaster::className(), ['id' => 'category_id']);
        }

        public function getIndustry() {
                return $this->hasOne(\backend\models\IndustriesMaster::className(), ['id' => 'industry_id']);
        }

        public function getMeasure() {
                return $this->hasOne(MeasuringParameter::className(), ['id' => 'mesured_in']);
        }

        public function getCatBy() {
                return $this->hasOne(\yii\web\Seller::className(), ['id' => 'created_by']);
        }

        public function getUpdatedBy() {
                return $this->hasOne(\yii\web\Seller::className(), ['id' => 'updated_by']);
        }

}
