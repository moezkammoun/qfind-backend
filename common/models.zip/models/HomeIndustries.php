<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "home_industries".
 *
 * @property integer $id
 * @property integer $main_industry
 * @property integer $sub_industry
 * @property integer $sort_order
 */
class HomeIndustries extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'home_industries';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['main_industry', 'sub_industry'], 'required'],
                    ['sub_industry', 'unique'],
                    [['main_industry', 'sub_industry', 'sort_order',], 'integer'],
                    [['status'], 'safe'],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'main_industry' => 'Main Industry',
                    'sub_industry' => 'Home Industry',
                    'sort_order' => 'Sort Order',
                ];
        }

        public function getMainind() {
                return $this->hasOne(\backend\models\IndustriesMaster::className(), ['id' => 'main_industry']);
        }

        public function getSubind() {
                return $this->hasOne(\backend\models\IndustriesMaster::className(), ['id' => 'sub_industry']);
        }

}
