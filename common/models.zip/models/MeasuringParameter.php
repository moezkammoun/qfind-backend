<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "measuring_parameter".
 *
 * @property integer $id
 * @property string $name
 * @property string $short_code
 * @property integer $status
 * @property string $image`
 */
class MeasuringParameter extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'measuring_parameter';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['name', 'short_code'], 'required'],
                    [['status'], 'integer'],
                    [['name', 'image'], 'string', 'max' => 200],
                    [['short_code'], 'string', 'max' => 50],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'name' => 'Name',
                    'short_code' => 'Short Code',
                    'status' => 'Status',
                    'image' => 'Image`',
                ];
        }

        public function upload($file, $id) {
                $targetFolder = \yii::$app->basePath . '/../uploads/measuring/' . $id . '/';
                if (!file_exists($targetFolder)) {
                        mkdir($targetFolder, 0777, true);
                }
                if ($file->saveAs($targetFolder . $file->name)) {
                        return true;
                } else {
                        return false;
                }
        }

}
