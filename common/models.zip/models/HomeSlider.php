<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "home_slider".
 *
 * @property integer $id
 * @property string $image
 * @property string $heading
 * @property string $banner_text_color
 * @property string $button_text
 * @property string $button_text_color
 * @property string $button_text_bg
 * @property string $content_alignment
 * @property string $description
 * @property integer $sort_order
 * @property integer $status
 * @property integer $cb
 * @property integer $ub
 * @property string $doc
 * @property string $dou
 * @property string $link_to
 */
class HomeSlider extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'home_slider';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['image'], 'required','on'=>'create'],
           // [['image', 'banner_text_color', 'button_text', 'button_text_color', 'button_text_bg', 'content_alignment'], 'required'],
            [['sort_order', 'status', 'cb', 'ub'], 'integer'],
            [['doc', 'dou'], 'safe'],
            [['image'], 'string', 'max' => 45],
            [['banner_text_color', 'button_text', 'button_text_color', 'button_text_bg', 'content_alignment'], 'string', 'max' => 100],
            [['description', 'link_to'], 'string', 'max' => 200],
            [['image'], 'file', 'extensions'=>'jpg,jpeg,png'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'image' => 'Image',
            'heading' => 'Heading (Use </br> for break heading to new line)',
            'banner_text_color' => 'Banner Text Color',
            'button_text' => 'Button Text',
            'button_text_color' => 'Button Text Color',
            'button_text_bg' => 'Button Text Bg',
            'content_alignment' => 'Content Alignment',
            'description' => 'Description',
            'sort_order' => 'Sort Order',
            'status' => 'Status',
            'cb' => 'Cb',
            'ub' => 'Ub',
            'doc' => 'Doc',
            'dou' => 'Dou',
            'link_to' => 'Link To',
        ];
    }
       public function upload($file, $id, $name) {

        $targetFolder = \yii::$app->basePath . '/../uploads/sliders/' . $id . '/';
        if (!file_exists($targetFolder)) {
            mkdir($targetFolder, 0777, true);
        }
        if ($file->saveAs($targetFolder . $id. '.' . $file->extension)) {
            return true;
        }
        else {
            return false;
        }
    }	
}
