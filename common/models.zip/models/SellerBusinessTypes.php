<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "seller_business_types".
 *
 * @property integer $id
 * @property integer $seller_id
 * @property integer $master_btype_id
 * @property integer $child_btype_id
 *
 * @property MasterBusinessTypes $childBtype
 */
class SellerBusinessTypes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'seller_business_types';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['seller_id', 'master_btype_id'], 'required'],
            [['seller_id', 'master_btype_id', 'child_btype_id'], 'integer'],
            [['child_btype_id'], 'exist', 'skipOnError' => true, 'targetClass' => MasterBusinessTypes::className(), 'targetAttribute' => ['child_btype_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'seller_id' => 'Seller ID',
            'master_btype_id' => 'Master Btype ID',
            'child_btype_id' => 'Child Btype ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getChildBtype()
    {
        return $this->hasOne(MasterBusinessTypes::className(), ['id' => 'child_btype_id']);
    }
}
