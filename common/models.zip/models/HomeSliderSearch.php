<?php

namespace common\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\HomeSlider;

/**
 * HomeSliderSearch represents the model behind the search form about `common\models\HomeSlider`.
 */
class HomeSliderSearch extends HomeSlider
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'sort_order', 'status', 'cb', 'ub'], 'integer'],
            [['image', 'heading', 'banner_text_color', 'button_text', 'button_text_color', 'button_text_bg', 'content_alignment', 'description', 'doc', 'dou', 'link_to'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = HomeSlider::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'sort_order' => $this->sort_order,
            'status' => $this->status,
            'cb' => $this->cb,
            'ub' => $this->ub,
            'doc' => $this->doc,
            'dou' => $this->dou,
        ]);

        $query->andFilterWhere(['like', 'image', $this->image])
            ->andFilterWhere(['like', 'heading', $this->heading])
            ->andFilterWhere(['like', 'banner_text_color', $this->banner_text_color])
            ->andFilterWhere(['like', 'button_text', $this->button_text])
            ->andFilterWhere(['like', 'button_text_color', $this->button_text_color])
            ->andFilterWhere(['like', 'button_text_bg', $this->button_text_bg])
            ->andFilterWhere(['like', 'content_alignment', $this->content_alignment])
            ->andFilterWhere(['like', 'description', $this->description])
            ->andFilterWhere(['like', 'link_to', $this->link_to]);

        return $dataProvider;
    }
}
