<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "product_description".
 *
 * @property integer $id
 * @property string $description
 * @property integer $status
 * @property integer $created_by
 * @property string $created_on
 */
class ProductDescription extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'product_description';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['description', 'product_id', 'created_by'], 'required'],
                    [['description'], 'string'],
                    [['status', 'created_by'], 'integer'],
                    [['created_on'], 'safe'],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'description' => 'Description',
                    'status' => 'Status',
                    'created_by' => 'Created By',
                    'created_on' => 'Created On',
                ];
        }

}
