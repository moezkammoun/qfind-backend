<?php

namespace common\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Sellers;

/**
 * SellersSearch represents the model behind the search form about `common\models\Sellers`.
 */
class SellersSearch extends Sellers
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'phone', 'status', 'email_verified', 'role', 'created_by', 'access_level', 'is_company', 'company_id'], 'integer'],
            [['name', 'canonical_name', 'email_id', 'fax', 'password', 'password_reset_token', 'auth_token', 'created_on', 'last_login'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Sellers::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'phone' => $this->phone,
            'created_on' => $this->created_on,
            'last_login' => $this->last_login,
            'status' => $this->status,
            'email_verified' => $this->email_verified,
            'role' => $this->role,
            'created_by' => $this->created_by,
            'access_level' => $this->access_level,
            'is_company' => $this->is_company,
            'company_id' => $this->company_id,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name])
            ->andFilterWhere(['like', 'canonical_name', $this->canonical_name])
            ->andFilterWhere(['like', 'email_id', $this->email_id])
            ->andFilterWhere(['like', 'fax', $this->fax])
            ->andFilterWhere(['like', 'password', $this->password])
            ->andFilterWhere(['like', 'password_reset_token', $this->password_reset_token])
            ->andFilterWhere(['like', 'auth_token', $this->auth_token]);

        return $dataProvider;
    }
    public function customSearch($params) {
        $query = Sellers::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'phone' => $this->phone,
            'created_on' => $this->created_on,
            'last_login' => $this->last_login,
            'status' => $this->status,
            'email_verified' => $this->email_verified,
            'role' => $this->role,
            'created_by' => $this->created_by,
            'access_level' => $this->access_level,
            'is_company' => $this->is_company,
            'company_id' => $this->company_id,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name])
                ->andFilterWhere(['like', 'canonical_name', $this->canonical_name])
                ->andFilterWhere(['like', 'email_id', $this->email_id])
                ->andFilterWhere(['like', 'fax', $this->fax])
                ->andFilterWhere(['like', 'password', $this->password])
                ->andFilterWhere(['like', 'password_reset_token', $this->password_reset_token])
                ->andFilterWhere(['like', 'created_by', Yii::$app->seller->identity->id])
                ->andFilterWhere(['like', 'auth_token', $this->auth_token]);

        return $dataProvider;
    }

}
