<?php

namespace common\models;

use yii\data\ActiveDataProvider;
use Yii;

/**
 * This is the model class for table "product_features".
 *
 * @property integer $id
 * @property string $features
 * @property integer $status
 * @property integer $created_by
 * @property integer $product_id
 * @property string $created_on
 */
class ProductFeatures extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'product_features';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['features', 'created_by', 'product_id'], 'required'],
                    [['features', 'product_id'], 'unique', 'targetAttribute' => ['features', 'product_id']],
                    [['status', 'created_by', 'product_id'], 'integer'],
                    [['created_on'], 'safe'],
                    [['features'], 'string', 'max' => 200],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'features' => 'Features',
                    'status' => 'Status',
                    'created_by' => 'Created By',
                    'product_id' => 'Product ID',
                    'created_on' => 'Created On',
                ];
        }

        public function loadFeatures($id) {
                $query = ProductFeatures::find();
                $dataProvider = new ActiveDataProvider([
                    'query' => $query,
                ]);
                $query->andFilterWhere([
                    'id' => $this->id,
                    'status' => $this->status,
                    'product_id' => $id,
                ]);
                return $dataProvider;
        }

}
