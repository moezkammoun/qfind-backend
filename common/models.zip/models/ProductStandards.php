<?php

namespace common\models;

use yii\data\ActiveDataProvider;
use Yii;

/**
 * This is the model class for table "product_standards".
 *
 * @property integer $id
 * @property string $standards
 * @property integer $status
 * @property integer $created_by
 * @property string $created_on
 * @property integer $product_id
 */
class ProductStandards extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'product_standards';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['standards', 'created_by', 'product_id'], 'required'],
                    [['standards', 'standards'], 'unique', 'targetAttribute' => ['standards', 'product_id']],
                    [['status', 'created_by', 'product_id'], 'integer'],
                    [['created_on'], 'safe'],
                    [['standards'], 'string', 'max' => 254],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'standards' => 'Standards',
                    'status' => 'Status',
                    'created_by' => 'Created By',
                    'created_on' => 'Created On',
                    'product_id' => 'Product ID',
                ];
        }

        public function loadStandards($id) {
                $query = ProductStandards::find();
                $dataProvider = new ActiveDataProvider([
                    'query' => $query,
                ]);
                $query->andFilterWhere([
                    'id' => $this->id,
                    'status' => $this->status,
                    'product_id' => $id,
                ]);
                return $dataProvider;
        }

}
