<?php

namespace common\models;

use yii\web\IdentityInterface;
use Yii;

/**
 * This is the model class for table "sellers".
 *
 * @property integer $id
 * @property string $name
 * @property string $email_id
 * @property integer $phone
 * @property string $password
 * @property string $password_reset_token
 * @property string $auth_token
 * @property string $created_on
 * @property string $last_login
 * @property integer $status
 * @property integer $role
 * @property integer $access_level
 * @property string $company_name
 * @property integer $is_company
 */
class Sellers extends \yii\db\ActiveRecord implements IdentityInterface {

        public $confirm;
        public $terms;

        const STATUS_DELETED = 0;
        const STATUS_ACTIVE = 10;

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'sellers';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['name', 'email_id', 'phone', 'password', 'is_company'], 'required'],
                    [['confirm'], 'required', 'on' => 'create'],
//                [['name', 'email_id', 'phone', 'password', 'confirm', 'is_company'], 'required', 'on' => 'secondLevel'],
                    [['phone', 'status', 'role', 'access_level', 'is_company'], 'integer'],
                    [['password_reset_token', 'auth_token'], 'string'],
                    [['created_on', 'last_login', 'role', 'access_level', 'since', 'canonical_name', 'fax', 'email_verified', 'created_by', 'company_id'], 'safe'],
                    [['name'], 'string', 'max' => 200],
                    [['email_id'], 'email'],
                    [['email_id'], 'unique'],
                    [['password'], 'string', 'max' => 100, 'min' => 6],
                    [['phone', 'fax'], 'string', 'max' => 20, 'min' => 5],
                    ['confirm', 'compare', 'compareAttribute' => 'password', 'message' => "Passwords don't match"],
                    [['phone', 'fax'], 'match',
                        'pattern' => '/^\+?\d+$/',
                        'message' => 'This field can contain only [+, 0- 9].'
                    ],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'name' => 'Name',
                    'email_id' => 'Email ID',
                    'phone' => 'Phone',
                    'password' => 'Password',
                    'confirm' => 'Confirm Password',
                    'password_reset_token' => 'Password Reset Token',
                    'auth_token' => 'Auth Token',
                    'created_on' => 'Created On',
                    'last_login' => 'Last Login',
                    'status' => 'Status',
                    'role' => 'Role',
                    'access_level' => 'Access Level',
//            'company_name' => 'Company Name',
                    'is_company' => 'Registration Type',
                ];
        }

        public static function findIdentity($id) {
                return static::findOne(['id' => $id]);
        }

        /**
         * @inheritdoc
         */
        public static function findIdentityByAccessToken($token, $type = null) {
                throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
        }

        /**
         * Finds user by username
         *
         * @param string $username
         * @return static|null
         */
        public static function findByUsername($username) {
                return static::findOne(['email_id' => $username]);
//        return static::findOne(['username' => $username, 'status' => self::STATUS_ACTIVE]);
        }

        /**
         * Finds user by password reset token
         *
         * @param string $token password reset token
         * @return static|null
         */
        public static function findByPasswordResetToken($token) {
                if (!static::isPasswordResetTokenValid($token)) {
                        return null;
                }

                return static::findOne([
                            'password_reset_token' => $token,
//                    'status' => self::STATUS_ACTIVE,
                ]);
        }

        /**
         * Finds out if password reset token is valid
         *
         * @param string $token password reset token
         * @return bool
         */
        public static function isPasswordResetTokenValid($token) {
                if (empty($token)) {
                        return false;
                }

                $timestamp = (int) substr($token, strrpos($token, '_') + 1);
                $expire = Yii::$app->params['user.passwordResetTokenExpire'];
                return $timestamp + $expire >= time();
        }

        /**
         * @inheritdoc
         */
        public function getId() {
                return $this->getPrimaryKey();
        }

        /**
         * @inheritdoc
         */
        public function getAuthKey() {
                return $this->auth_token;
        }

        /**
         * @inheritdoc
         */
        public function validateAuthKey($authKey) {
                return $this->getAuthKey() === $authKey;
        }

        /**
         * Validates password
         *
         * @param string $password password to validate
         * @return bool if password provided is valid for current user
         */
        public function validatePassword($password) {
                return Yii::$app->security->validatePassword($password, $this->password);
        }

        /**
         * Generates password hash from password and sets it to the model
         *
         * @param string $password
         */
        public function setPassword($password) {
                $this->password_hash = Yii::$app->security->generatePasswordHash($password);
        }

        /**
         * Generates "remember me" authentication key
         */
        public function generateAuthKey() {
                $this->auth_token = Yii::$app->security->generateRandomString();
        }

        /**
         * Generates new password reset token
         */
        public function generatePasswordResetToken() {
                $this->password_reset_token = Yii::$app->security->generateRandomString() . '_' . time();
        }

        /**
         * Removes password reset token
         */
        public function removePasswordResetToken() {
                $this->password_reset_token = null;
        }

        public function getCompany() {
                return $this->hasOne(CompanyProfile::className(), ['id' => 'company_id']);
        }

}
