<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "home_category".
 *
 * @property integer $id
 * @property integer $cat_id
 * @property integer $status
 * @property integer $sort_order
 */
class HomeCategory extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'home_category';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['cat_id'], 'required'],
                    [['cat_id', 'status', 'sort_order'], 'integer'],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'cat_id' => 'Category',
                    'status' => 'Status',
                    'sort_order' => 'Sort Order',
                ];
        }

        public function getCat() {
                return $this->hasOne(\backend\models\CategoriesMaster::className(), ['id' => 'cat_id']);
        }

}
