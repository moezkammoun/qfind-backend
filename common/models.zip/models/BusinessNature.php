<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "business_nature".
 *
 * @property integer $id
 * @property string $name
 * @property string $canonical_name
 * @property string $image
 * @property integer $sort_order
 * @property integer $status
 */
class BusinessNature extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'business_nature';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['name', 'canonical_name', 'status'], 'required'],
            [['sort_order', 'status'], 'integer'],
            [['name', 'canonical_name', 'image'], 'string', 'max' => 250],
            ['canonical_name', 'unique', 'targetAttribute' => ['canonical_name'], 'message' => 'Canonical Name must be unique.'],
            ['canonical_name', 'match', 'pattern' => '/^[A-Za-z0-9-]+$/'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'canonical_name' => 'Canonical Name',
            'image' => 'Image',
            'sort_order' => 'Sort Order',
            'status' => 'Status',
        ];
    }
 public function upload($file, $id, $name) {

        $targetFolder = \yii::$app->basePath . '/../uploads/business-nature/' . $id . '/';
        if (!file_exists($targetFolder)) {
            mkdir($targetFolder, 0777, true);
        }
        if ($file->saveAs($targetFolder . $name)) {
            return true;
        } else {
            return false;
        }
    }
}
