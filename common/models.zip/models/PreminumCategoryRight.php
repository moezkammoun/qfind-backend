<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "preminum_category_right".
 *
 * @property integer $id
 * @property integer $cat_id
 * @property integer $status
 * @property integer $sort_order
 */
class PreminumCategoryRight extends \yii\db\ActiveRecord {

        /**
         * @inheritdoc
         */
        public static function tableName() {
                return 'preminum_category_right';
        }

        /**
         * @inheritdoc
         */
        public function rules() {
                return [
                    [['cat_id'], 'required'],
                    [['cat_id', 'status', 'sort_order'], 'integer'],
                ];
        }

        /**
         * @inheritdoc
         */
        public function attributeLabels() {
                return [
                    'id' => 'ID',
                    'cat_id' => 'category',
                    'status' => 'Status',
                    'sort_order' => 'Sort Order',
                ];
        }

        public function getCat() {
                return $this->hasOne(\backend\models\CategoriesMaster::className(), ['id' => 'cat_id']);
        }

}
